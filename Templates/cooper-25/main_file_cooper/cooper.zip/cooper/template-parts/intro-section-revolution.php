<!--=============== hero-wrapper ===============-->
                    <div id="cooper-rev" class="hero-wrap fl-wrap full-height">
                            
                            <?php echo do_shortcode(get_post_meta($post->ID,'rnr_rev-alias',true)) ?>
							
                       
                    </div>
                    <!-- hero-wrapper  end -->