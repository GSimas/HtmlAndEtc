					
                <div class="searh-holder fl-wrap">
                    <div class="searh-inner">
                        <form id="searchfrom" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                            <input name="s" type="text" class="search" placeholder="<?php esc_attr_e('Search..','cooper');?>" />
                            <button class="search-submit" id="submit_btn"><i class="fa fa-search transition"></i> </button>
                        </form>
                    </div>
                </div>
				
