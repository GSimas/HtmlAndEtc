<?php defined('ABSPATH') or die("No script kiddies please!");?>
<?php $cooper_options = get_option('cooper_wp'); ?> 
   
<?php wp_footer(); ?>
</body>
</html>